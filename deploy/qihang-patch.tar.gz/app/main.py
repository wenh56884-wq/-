# app/main.py
# 职责：FastAPI 应用工厂、路由注册、统一异常与请求级审计中间件
# 依赖：app.auth / app.routers.* / app.schemas / app.audit / engine.store
# 说明：容器化模式下 `uvicorn app.main:app`；本地演示 `python app\main.py`

from __future__ import annotations

import time
import uuid

import pymysql
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarsHTTPException

from agents.tools import ToolContext
from app.audit import audit_event
from app.auth import (
    ROLE_STUDENT,
    ROLE_TEACHER,
    authenticate,
    create_access_token,
    get_current_ctx,
    validate_security_config,
)
from app.config import get_settings
from app.logging_config import get_logger
from app.routers import assessment as assessment_router
from app.routers import career as career_router
from app.routers import chat as chat_router
from app.routers import elective as elective_router
from app.routers import exam as exam_router
from app.routers import export as export_router
from app.routers import forecast as forecast_router
from app.routers import grades as grades_router
from app.routers import interview as interview_router
from app.routers import job as job_router
from app.routers import kb as kb_router
from app.routers import kg as kg_router
from app.routers import pet as pet_router
from app.routers import question_bank as qb_router
from app.routers import student as student_router
from app.routers import teacher as teacher_router
from app.routers import web as web_router
from app.routers import workflow as workflow_router
from app.schemas import ChatIn, ChatOut, HealthOut, LoginIn, LoginOut

APP_TITLE = "启航 · 学业预警与职业发展助手 API"
APP_VERSION = "1.0.0"

# .env 同时供 pydantic 与直接读 os.getenv 的适配层使用，必须先加载。
load_dotenv()
logger = get_logger("qihang.api")

def _check_mysql() -> str:
    """真实连通检测：能连上并查到任意一行即 ok。"""
    s = get_settings()
    conn = pymysql.connect(host=s.mysql_host, port=s.mysql_port, user=s.mysql_user,
                           password=s.mysql_password, database=s.mysql_db,
                           charset="utf8mb4", connect_timeout=5)
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
            cur.fetchone()
        return "ok"
    finally:
        conn.close()


def _check_duckdb() -> str:
    """真实连通检测：读一次分析库（health_check）。"""
    try:
        from engine.store import DuckDBStore

        return "ok" if DuckDBStore().health_check() else "down"
    except Exception:
        logger.warning("DuckDB health check failed", exc_info=True)
        return "down"


def _run_chat(ctx: ToolContext, body: ChatIn) -> dict:
    """跑一次对话，返回完整结果（answer / degraded / session_id / citations）。

    优先走 chat_service（会落库、带多轮记忆）；落库层不可用时退回纯图调用，
    回答照常给，只是这一轮不留痕——不因为存储问题让用户拿不到答案。
    """
    try:
        from app import chat_service
        from app.chat_service import QuotaExceeded

        try:
            return chat_service.handle(ctx, body.query, body.term, body.session_id, body.history)
        except QuotaExceeded as exc:
            # 配额用尽要原样透出，不能掉进下面的「图调用兜底」绕过配额
            return {"answer": str(exc), "degraded": False, "session_id": None,
                    "tool_name": "", "citations": [], "suggested_followups": [],
                    "quota_exceeded": True}
    except Exception:
        logger.warning("chat_service unavailable; fallback to graph", exc_info=True)
    try:
        from agents.graph import run_chat  # 延迟导入：P7 接入后即生效
    except Exception:
        logger.exception("agent graph import failed")
        audit_event(
            tenant_id=ctx.tenant_id, actor_type=ctx.actor_type,
            actor_id=ctx.student_id or ctx.teacher_id or 0,
            action="api.chat.unavailable", target="", detail={"stage": "import"},
        )
        return {"answer": "智能体编排尚未启用，暂无法回答该问题。"
                          "你可以先查看「预警列表」与「个人画像」中的结构化数据。",
                "degraded": True, "session_id": None, "tool_name": "", "citations": []}
    try:
        return run_chat(ctx, body.query, term=body.term,
                        history=[{"role": turn.role, "text": turn.text}
                                 for turn in (body.history or [])])
    except Exception:
        logger.exception("chat pipeline failed")
        audit_event(
            tenant_id=ctx.tenant_id, actor_type=ctx.actor_type,
            actor_id=ctx.student_id or ctx.teacher_id or 0,
            action="api.chat.failed", target="", detail={"stage": "pipeline"},
        )
        return {"answer": "智能体处理失败，已降级为安全话术（不提供任何未经核对的数值）。",
                "degraded": True, "session_id": None, "tool_name": "", "citations": []}


_NON_AUDIT_PREFIXES = (
    "/assets/",
    "/media/",
    "/favicon",
    "/docs",
    "/redoc",
    "/openapi.json",
)


def _should_persist_db_audit(request: Request, status_code: int) -> bool:
    """数据库只留失败请求和业务审计；成功访问写滚动文件日志。"""
    path = request.url.path
    if path.startswith(_NON_AUDIT_PREFIXES):
        return False
    if path == "/health":
        return False
    return status_code >= 400


def create_app() -> FastAPI:
    validate_security_config()
    """构造 FastAPI 应用（工厂函数，便于测试与托管）。"""
    app = FastAPI(title=APP_TITLE, version=APP_VERSION,
                  responses={401: {"model": None}, 403: {"model": None}})

    # 开发期允许 Vue dev server 直连；演示托管模式下此策略无害（同源请求）
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # 静态资源与 JSON 走 gzip：JS/CSS 可再省约 70% 传输量。
    # Starlette 默认排除 text/event-stream、video/*、image/webp、woff2，
    # 因此不会影响 /chat/stream 的 SSE 和视频/字体。
    app.add_middleware(GZipMiddleware, minimum_size=1024, compresslevel=6)

    app.include_router(assessment_router.router)
    app.include_router(teacher_router.router)
    app.include_router(student_router.router)
    app.include_router(career_router.router)
    app.include_router(elective_router.router)
    app.include_router(forecast_router.router)
    app.include_router(grades_router.router)
    app.include_router(exam_router.router)
    app.include_router(export_router.router)
    app.include_router(job_router.router)
    app.include_router(interview_router.router)
    app.include_router(kg_router.router)
    app.include_router(qb_router.router)
    app.include_router(kb_router.router)
    app.include_router(chat_router.router)
    app.include_router(web_router.router)
    app.include_router(workflow_router.router)
    app.include_router(pet_router.router)

    @app.middleware("http")
    async def audit_middleware(request: Request, call_next):
        """请求级追踪：全部访问写文件日志，失败请求另落数据库审计。"""
        started = time.perf_counter()
        request_id = uuid.uuid4().hex[:16]
        request.state.request_id = request_id
        tenant_id, actor_type, actor_id = 0, "anonymous", 0
        header = request.headers.get("authorization", "")
        if header.lower().startswith("bearer "):
            try:
                from app.auth import decode_token

                claims = decode_token(header.split(" ", 1)[1].strip())
                tenant_id = int(claims.get("tenant_id") or 0)
                actor_type = str(claims.get("role") or "anonymous")
                actor_id = int(claims.get("student_id")
                               or claims.get("teacher_id") or 0)
            except Exception:  # token 无效：按匿名留痕，由依赖层决定 401
                tenant_id, actor_type, actor_id = 0, "invalid-token", 0
        status_code = 500
        try:
            response = await call_next(request)
            status_code = response.status_code
            response.headers["X-Request-ID"] = request_id
            return response
        finally:
            duration_ms = (time.perf_counter() - started) * 1000
            log_method = logger.warning if status_code >= 400 else logger.info
            log_method(
                "request_id=%s tenant_id=%s actor_type=%s actor_id=%s "
                "method=%s path=%s status=%s duration_ms=%.2f",
                request_id, tenant_id, actor_type, actor_id,
                request.method, request.url.path, status_code, duration_ms,
            )
            if _should_persist_db_audit(request, status_code):
                audit_event(
                    tenant_id=tenant_id, actor_type=actor_type, actor_id=actor_id,
                    action=f"{request.method} {request.url.path}",
                    target=request.url.query or "",
                    detail={"status": status_code, "request_id": request_id},
                    duration_ms=duration_ms,
                )

    @app.exception_handler(PermissionError)
    async def _permission_handler(request: Request, exc: PermissionError):
        return JSONResponse(status_code=status.HTTP_403_FORBIDDEN,
                            content={"detail": str(exc)})

    @app.exception_handler(HTTPException)
    async def _http_handler(request: Request, exc: HTTPException):
        return JSONResponse(status_code=exc.status_code,
                            content={"detail": exc.detail})

    @app.exception_handler(Exception)
    async def _server_handler(request: Request, exc: Exception):
        # 统一 500：中文提示，不外泄任何堆栈或内部信息
        logger.error(
            "unhandled request exception request_id=%s method=%s path=%s",
            getattr(request.state, "request_id", "-"),
            request.method,
            request.url.path,
            exc_info=(type(exc), exc, exc.__traceback__),
        )
        return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            content={"detail": "服务内部错误，请联系运维查看日志"},
                            headers={"X-Request-ID": getattr(
                                request.state, "request_id", "-"
                            )})

    @app.get("/health", response_model=HealthOut, tags=["系统"])
    def health() -> HealthOut:
        """真实检测 MySQL 与 DuckDB 连通；llm 只检查 key 是否配置。"""
        try:
            db = _check_mysql()
        except Exception:
            logger.warning("MySQL health check failed", exc_info=True)
            db = "down"
        duckdb_state = _check_duckdb()
        try:
            from agents.llm import provider_order

            llm_state = "configured" if provider_order() else "missing"
        except Exception:
            logger.warning("LLM provider detection failed", exc_info=True)
            llm_state = "missing"
        return HealthOut(
            status="ok" if (db == "ok" and duckdb_state == "ok") else "degraded",
            db=db,
            duckdb=duckdb_state,
            llm=llm_state,
        )

    @app.post("/auth/login", response_model=LoginOut, tags=["系统"])
    def login(body: LoginIn) -> LoginOut:
        """登录：teacher 用工号、student 用学号；失败统一 401『账号或口令错误』。"""
        role = str(body.role or "").strip()
        if role not in (ROLE_TEACHER, ROLE_STUDENT):
            raise HTTPException(status_code=422,
                                detail="role 只能是 teacher 或 student")
        identity = authenticate(role, body.account, body.password, body.tenant_id)
        if identity is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                detail="账号或口令错误")
        token, expires_in = create_access_token(identity)
        audit_event(tenant_id=identity["tenant_id"], actor_type=role,
                    actor_id=identity["actor_id"],
                    action="auth.login", target=str(body.account), detail={"ok": True})
        return LoginOut(
            access_token=token, token_type="bearer", role=role,
            tenant_id=identity["tenant_id"], actor_id=identity["actor_id"],
            student_no=identity.get("student_no"), expires_in=expires_in,
        )

    @app.post("/chat", response_model=ChatOut, tags=["系统"])
    def chat(body: ChatIn,
             ctx: ToolContext = Depends(get_current_ctx)) -> ChatOut:
        """对话：调 LangGraph；返回 answer + trace_id，便于 Critic 回查工具结果。

        身份只从 get_current_ctx 取（已校验角色与租户），不再手工解析 claims。
        """
        result = _run_chat(ctx, body)
        answer = str(result.get("answer") or "").strip()
        degraded = bool(result.get("degraded"))
        if not answer:
            answer, degraded = "未得到可用答复，已降级为安全话术。", True
        # 必须沿用图/服务返回的 trace_id：反馈接口按它回查审计，不能另生成一个
        trace_id = str(result.get("trace_id") or uuid.uuid4().hex[:12])
        return ChatOut(
            answer=answer, trace_id=trace_id, term=body.term,
            degraded=degraded, session_id=result.get("session_id"),
            tool=str(result.get("tool_name") or ""),
            citations=list(result.get("citations") or []),
            suggested_followups=list(result.get("suggested_followups") or []),
            attempts=int(result.get("attempts") or 1),
            verdict=dict(result.get("verdict") or {}),
            draft_mode=str(result.get("draft_mode") or ""),
            planner=str(result.get("planner") or ""),
            critic_version=str(result.get("critic_version") or ""),
            graph_version=str(result.get("graph_version") or ""),
            engine_version=str(result.get("engine_version") or ""),
            calc_version=str(result.get("calc_version") or ""),
        )

    # --- 静态托管（P10-3）：构建产物存在才挂，已注册路由与 /api 不受影响 ---
    dist = get_settings().frontend_dist_obj
    if dist is not None:
        app.mount("/", StaticFiles(directory=str(dist), html=True), name="frontend")

        @app.exception_handler(StarsHTTPException)
        async def _spa_fallback(request: Request, exc: StarsHTTPException):
            """未命中的前端路由（如 /teacher）回落到 index.html，交给 Vue Router 接管。"""
            if exc.status_code == 404 and not request.url.path.startswith("/api"):
                return FileResponse(dist / "index.html")
            return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

    return app


app = create_app()

# 建 AI 宠物陪伴表（幂等）；MySQL 未就绪时跳过，宠物降级为内存模式
try:
    from app.routers.pet import init_db as _init_pet_db

    _init_pet_db()
except Exception:  # 建表异常不能拖垮接口服务
    logger.exception("pet db init failed")

# 后台定时同步：官方一发布新竞赛通知就自动入库，学生端随即看到未读推送
try:
    from app.competition_sync import start_background_sync

    start_background_sync()
except Exception:  # 同步模块异常不能拖垮接口服务
    logger.exception("competition sync startup failed")

# 后台周更：招考公告（考公 / 考编 / 考研）每周抓一次并增量入库
# 间隔由 RECRUIT_SYNC_HOURS 控制（默认 168 小时 = 一周；0 关闭）
try:
    from app.recruit_sync import start_background_sync as start_recruit_sync

    start_recruit_sync()
except Exception:
    logger.exception("recruit sync startup failed")

# 后台同步：国考职位（《招考简章》年度数据）定期增量入库
# 间隔由 GUOKAO_SYNC_HOURS 控制（默认 168 小时 = 一周；0 关闭）
try:
    from app.guokao_sync import start_background_sync as start_guokao_sync

    start_guokao_sync()
except Exception:
    logger.exception("guokao sync startup failed")


if __name__ == "__main__":  # pragma: no cover
    import uvicorn

    settings = get_settings()
    uvicorn.run("app.main:app", host="127.0.0.1", port=settings.app_port, reload=False)
