# app/routers/export.py
# 职责：学生档案 / 成绩数据的下载接口（xlsx / csv / json）
# 依赖：app.exporters（渲染）、agents.tools（取数与权限）、engine.warning（口径）
# 说明：数值一律复用引擎与工具层，导出层只做「取数 → 摆列 → 换容器」，
#       不允许在这里重新计算，否则导出的数和页面显示的对不上。

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from agents import tools
from agents.tools import ToolContext
from app import exporters
from app.auth import require_student, require_teacher
from engine import warning

router = APIRouter(prefix="/export", tags=["数据导出"])

# 等级中文文案：与前端 TeacherStudents.vue 的 LEVELS 逐字一致，
# 导出的表和页面看到的必须是同一套说法
_LEVEL_TEXT = {"red": "红色预警", "orange": "橙色预警", "yellow": "黄色预警",
               "none": "正常", "unknown": "数据不足"}

_FMT = Query(default="xlsx", pattern="^(xlsx|csv|json)$",
             description="下载格式：xlsx / csv / json")


def _safe(text: str) -> str:
    """文件名去掉路径分隔符等非法字符，避免浏览器丢弃整个文件名。"""
    return "".join("-" if ch in '\\/:*?"<>|' else ch for ch in str(text)).strip() or "导出"


def _num(value: Any, digits: int = 2) -> float | None:
    """Decimal/str → float，供 Excel 识别为数值单元格；None 保持 None。"""
    if value is None or value == "":
        return None
    try:
        return round(float(value), digits)
    except (TypeError, ValueError):
        return None


def _student_base(ctx: ToolContext, class_name: str) -> list[dict[str, Any]]:
    """班级学生基础信息（学院/专业/年级不在预警引擎返回里，单独取一次）。"""
    return tools._query(
        "SELECT `学号` AS student_no, `姓名` AS name, `学院` AS college, "
        "       `专业` AS major, `班级` AS class_name, `年级` AS grade "
        "FROM `学生` WHERE `租户编号` = %s AND `班级` = %s ORDER BY `学号`",
        (ctx.tenant_id, class_name))


def _warning_map(ctx: ToolContext, class_name: str, term: str) -> dict[str, dict[str, Any]]:
    """预警引擎结果按学号索引；引擎不可用时返回空字典，导出退化为纯档案。"""
    try:
        results = warning.compute_class(ctx.tenant_id, class_name, term)
    except Exception:  # 引擎异常不能让人连档案都导不出来
        return {}
    return {str(r.get("student_no")): r for r in results}


# ---------------------------------------------------------------- 学生档案
_STUDENT_HEADERS = [
    "学号", "姓名", "学院", "专业", "班级", "年级",
    "预警等级", "风险分", "预警原因", "数据覆盖率",
    "GPA", "挂科数", "出勤率", "班级排名百分位",
]


def _student_matrix(ctx: ToolContext, class_name: str, term: str,
                    level: str) -> tuple[list[list[Any]], list[dict[str, Any]]]:
    """返回 (二维表行, 结构化记录)；两者同源，JSON 与表格内容一致。"""
    base = _student_base(ctx, class_name)
    warns = _warning_map(ctx, class_name, term)
    wanted = {lv.strip() for lv in str(level or "").split(",") if lv.strip()}

    rows: list[list[Any]] = []
    records: list[dict[str, Any]] = []
    for stu in base:
        no = str(stu.get("student_no"))
        warn = warns.get(no) or {}
        lv = str(warn.get("level") or "none")
        if wanted and lv not in wanted:
            continue
        metrics = warn.get("metrics") or {}
        reasons = "；".join(warn.get("reasons") or [])
        row = [
            no, stu.get("name") or "", stu.get("college") or "",
            stu.get("major") or "", stu.get("class_name") or "",
            stu.get("grade") or "",
            _LEVEL_TEXT.get(lv, lv),
            int(warn["risk_score"]) if warn.get("risk_score") is not None else None,
            reasons,
            int(warn["coverage"]) if warn.get("coverage") is not None else None,
            _num(metrics.get("gpa")),
            int(metrics["fail_count"]) if metrics.get("fail_count") is not None else None,
            _num(metrics.get("attendance_rate"), 4),
            _num(metrics.get("class_rank_pct"), 1),
        ]
        rows.append(row)
        records.append({
            "student_no": no, "name": stu.get("name"), "college": stu.get("college"),
            "major": stu.get("major"), "class_name": stu.get("class_name"),
            "grade": stu.get("grade"), "level": lv,
            "risk_score": warn.get("risk_score"), "reasons": warn.get("reasons") or [],
            "coverage": warn.get("coverage"), "metrics": metrics,
        })
    return rows, records


@router.get("/students")
def export_students(
    class_name: str = Query(description="班级名，必须属于本租户/任教范围"),
    term: str = Query(default="", description="学期；留空取引擎默认学期"),
    level: str = Query(default="", description="预警等级过滤，逗号分隔；留空=全部"),
    fmt: str = _FMT,
    ctx: ToolContext = Depends(require_teacher),
) -> Any:
    """导出班级学生档案：名单 + 预警等级 + 风险分 + 归因 + 关键学业指标。"""
    try:
        tools._require_class(ctx, class_name, "export_students")
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    term_used = tools._resolve_term(ctx, term)
    rows, records = _student_matrix(ctx, class_name, term_used, level)
    tools._audit_call(ctx, "export_students", f"{class_name}/{term_used}",
                      {"format": fmt, "count": len(rows), "level": level or "all"})

    stem = _safe(f"学生档案-{class_name}-{term_used}")
    return exporters.build_response(
        fmt, stem,
        headers=_STUDENT_HEADERS, rows=rows,
        sheets=[("学生档案", _STUDENT_HEADERS, rows)],
        ascii_stem=_safe(f"students-{class_name}-{term_used}"),
        payload={
            "class_name": class_name, "term": term_used,
            "level": level or "all", "total": len(records),
            "exported_at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
            "students": records,
        },
    )


# ---------------------------------------------------------------- 成绩
_GRADE_HEADERS = ["学号", "姓名", "班级", "学期", "课程编号", "课程名称",
                  "学分", "分数", "是否及格", "是否重修"]

_GRADE_SQL = (
    "SELECT s.`学号` AS student_no, s.`姓名` AS name, s.`班级` AS class_name, "
    "       sc.`学期` AS term, c.`课程编号` AS course_code, "
    "       c.`课程名称` AS course_name, c.`学分` AS credit, "
    "       sc.`分数` AS score, sc.`是否重修` AS retake "
    "FROM `成绩` sc "
    "JOIN `学生` s ON s.`编号` = sc.`学生编号` "
    "LEFT JOIN `课程` c ON c.`编号` = sc.`课程编号` "
    "WHERE s.`租户编号` = %s AND sc.`学期` = %s "
)


def _grade_rows(rows: list[dict[str, Any]]) -> list[list[Any]]:
    out: list[list[Any]] = []
    for r in rows:
        score = _num(r.get("score"))
        out.append([
            str(r.get("student_no") or ""), r.get("name") or "",
            r.get("class_name") or "", r.get("term") or "",
            r.get("course_code") or "", r.get("course_name") or "",
            _num(r.get("credit"), 1), score,
            "" if score is None else ("及格" if score >= 60 else "不及格"),
            "是" if int(r.get("retake") or 0) else "否",
        ])
    return out


def _summary_rows(rows: list[dict[str, Any]]) -> list[list[Any]]:
    """按学生汇总：均分 / 加权均分 / 门数 / 挂科数。与成绩单口径一致（取全部记录）。"""
    agg: dict[str, dict[str, Any]] = {}
    for r in rows:
        key = str(r.get("student_no") or "")
        if key not in agg:
            agg[key] = {"name": r.get("name") or "", "class_name": r.get("class_name") or "",
                        "scores": [], "weighted_num": 0.0, "weighted_den": 0.0,
                        "courses": set(), "fails": set()}
        item = agg[key]
        score = _num(r.get("score"))
        credit = _num(r.get("credit"), 1) or 0.0
        item["courses"].add(str(r.get("course_code") or ""))
        if score is None:
            continue
        item["scores"].append(score)
        if credit:
            item["weighted_num"] += score * credit
            item["weighted_den"] += credit
        if score < 60:
            item["fails"].add(str(r.get("course_code") or ""))

    out: list[list[Any]] = []
    for no, item in sorted(agg.items()):
        scores = item["scores"]
        avg = round(sum(scores) / len(scores), 2) if scores else None
        weighted = (round(item["weighted_num"] / item["weighted_den"], 2)
                    if item["weighted_den"] else None)
        # 修读门数按课程编号去重，成绩记录数含重修重复记录——两者口径不同，不能混用
        out.append([no, item["name"], item["class_name"], len(item["courses"]),
                    len(scores), avg, weighted, len(item["fails"])])
    return out


_SUMMARY_HEADERS = ["学号", "姓名", "班级", "修读门数", "成绩记录数",
                    "平均分", "加权均分", "挂科门数"]


@router.get("/grades")
def export_grades(
    class_name: str = Query(description="班级名，必须属于本租户/任教范围"),
    term: str = Query(default="", description="学期；留空取引擎默认学期"),
    fmt: str = _FMT,
    ctx: ToolContext = Depends(require_teacher),
) -> Any:
    """导出全班成绩明细（每生每课一行）+ 个人汇总（Excel 里分两个 sheet）。"""
    try:
        tools._require_class(ctx, class_name, "export_grades")
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    term_used = tools._resolve_term(ctx, term)
    raw = tools._query(
        _GRADE_SQL + "AND s.`班级` = %s ORDER BY s.`学号`, c.`课程编号`",
        (ctx.tenant_id, term_used, class_name))
    rows = _grade_rows(raw)
    summary = _summary_rows(raw)
    tools._audit_call(ctx, "export_grades", f"{class_name}/{term_used}",
                      {"format": fmt, "records": len(rows)})

    stem = _safe(f"班级成绩-{class_name}-{term_used}")
    return exporters.build_response(
        fmt, stem,
        headers=_GRADE_HEADERS, rows=rows,
        sheets=[("成绩明细", _GRADE_HEADERS, rows),
                ("个人汇总", _SUMMARY_HEADERS, summary)],
        ascii_stem=_safe(f"class-grades-{class_name}-{term_used}"),
        payload={
            "class_name": class_name, "term": term_used,
            "record_count": len(rows), "student_count": len(summary),
            "summary": [dict(zip(_SUMMARY_HEADERS, r)) for r in summary],
            "records": [dict(zip(_GRADE_HEADERS, r)) for r in rows],
        },
    )


def _one_student_grades(ctx: ToolContext, student_no: str, term: str) -> list[dict[str, Any]]:
    """单人成绩：两条独立 SQL 而不是字符串拼接，避免改动主 SQL 时静默错位。"""
    cols = ("SELECT s.`学号` AS student_no, s.`姓名` AS name, s.`班级` AS class_name, "
            "       sc.`学期` AS term, c.`课程编号` AS course_code, "
            "       c.`课程名称` AS course_name, c.`学分` AS credit, "
            "       sc.`分数` AS score, sc.`是否重修` AS retake "
            "FROM `成绩` sc "
            "JOIN `学生` s ON s.`编号` = sc.`学生编号` "
            "LEFT JOIN `课程` c ON c.`编号` = sc.`课程编号` ")
    if term:
        return tools._query(
            cols + "WHERE s.`租户编号` = %s AND sc.`学期` = %s AND s.`学号` = %s "
                   "ORDER BY sc.`学期`, c.`课程编号`",
            (ctx.tenant_id, term, student_no))
    return tools._query(
        cols + "WHERE s.`租户编号` = %s AND s.`学号` = %s "
               "ORDER BY sc.`学期`, c.`课程编号`",
        (ctx.tenant_id, student_no))


@router.get("/student-grades/{student_no}")
def export_student_grades(
    student_no: str,
    term: str = Query(default="", description="学期；留空导出全部学期"),
    fmt: str = _FMT,
    ctx: ToolContext = Depends(require_teacher),
) -> Any:
    """教师导出某一名学生的完整成绩单（默认跨全部学期）。"""
    try:
        stu = tools._fetch_student(ctx, student_no, "export_student_grades")
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    raw = _one_student_grades(ctx, str(stu["student_no"]), term)
    rows = _grade_rows(raw)
    tools._audit_call(ctx, "export_student_grades", str(student_no),
                      {"format": fmt, "records": len(rows)})

    stem = _safe(f"成绩单-{stu.get('name') or ''}-{stu['student_no']}")
    return exporters.build_response(
        fmt, stem,
        headers=_GRADE_HEADERS, rows=rows,
        sheets=[("成绩单", _GRADE_HEADERS, rows)],
        ascii_stem=f"grade-report-{stu['student_no']}",
        payload={
            "student": {k: stu.get(k) for k in
                        ("student_no", "name", "major", "class_name", "college", "enroll_year")},
            "term": term or "全部学期",
            "record_count": len(rows),
            "records": [dict(zip(_GRADE_HEADERS, r)) for r in rows],
        },
    )


@router.get("/my-grades")
def export_my_grades(
    term: str = Query(default="", description="学期；留空导出全部学期"),
    fmt: str = _FMT,
    ctx: ToolContext = Depends(require_student),
) -> Any:
    """学生导出自己的成绩单：学号只来自 JWT，不接受任何入参指定他人。"""
    try:
        stu = tools._resolve_self(ctx, "export_my_grades")
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc))

    raw = _one_student_grades(ctx, str(stu["student_no"]), term)
    rows = _grade_rows(raw)
    tools._audit_call(ctx, "export_my_grades", str(stu["student_no"]),
                      {"format": fmt, "records": len(rows)})

    stem = _safe(f"我的成绩单-{stu['student_no']}")
    return exporters.build_response(
        fmt, stem,
        headers=_GRADE_HEADERS, rows=rows,
        sheets=[("我的成绩单", _GRADE_HEADERS, rows)],
        ascii_stem=f"my-grades-{stu['student_no']}",
        payload={
            "student": {k: stu.get(k) for k in
                        ("student_no", "name", "major", "class_name", "enroll_year")},
            "term": term or "全部学期",
            "record_count": len(rows),
            "records": [dict(zip(_GRADE_HEADERS, r)) for r in rows],
        },
    )
