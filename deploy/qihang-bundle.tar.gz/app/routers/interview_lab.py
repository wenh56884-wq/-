# app/routers/interview_lab.py
# 职责：面试实验室 API——把面试结果与校内学业数据交叉，产出商业产品做不到的结论：
#   1) 圆桌评审（三面试官独立打分 + 分歧度）
#   2) 失分溯源（漏考点 → 具体课程 → 成绩分位）
#   3) 同辈分位（同专业同年级实测基准，样本不足诚实降级为课程代理）
#   4) 群面（无领导小组讨论）四方抢话模拟
#   5) 能力护照 / 示范骨架 / 复盘卡 / 表达力度量
# 铁律：分数一律由 engine 计算，本层只做取数与拼装；模型只组织语言且必须可降级；
#       学生只能访问本人数据，越权一律 404（不泄露存在性）。

from __future__ import annotations

import json
import math
import os
import time
import uuid
from collections import defaultdict
from typing import Any, Mapping, Sequence

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from agents import llm as llm_client
from agents.tools import ToolContext
from app.auth import require_student
from app.routers.interview import _conn, _evidence, _load_resume, _one, _rows, _rubric_of_q
from engine import attribution as attr_engine
from engine import expression as expr_engine
from engine import group as group_engine
from engine import passport as passport_engine
from engine import peer as peer_engine
from engine import shadow as shadow_engine
from engine.kg import skills_for_course
from engine.interview import (
    QUESTION_TYPES,
    aggregate,
    core_problems,
    gap_list,
    improvement_plan,
    score_answer,
)
from engine.panel import dimension_percent, review

router = APIRouter(prefix="/interview/lab", tags=["interview-lab"])

DIMS = ("content", "structure", "depth", "evidence")
DIM_LABELS = {"content": "内容", "structure": "结构", "depth": "深度", "evidence": "证据"}

# 群面会话：进程内存储（单 worker，见 Dockerfile）；30 分钟 TTL，最多 200 场
_GROUP_TTL = 30 * 60
_GROUP_MAX = 200
_GROUP_SESSIONS: dict[str, dict[str, Any]] = {}


class ExpressionIn(BaseModel):
    text: str = ""
    duration_sec: float | None = None
    segments: list[dict[str, Any]] | None = None


class GroupStartIn(BaseModel):
    job_id: int | None = None
    job_title: str | None = None
    industry: str | None = None
    skills: list[str] | None = None


class GroupTurnIn(BaseModel):
    state: dict[str, Any]
    text: str | None = None


# ----------------------------------------------------------------
# 取数：一场已完成面试的全部上下文（自带越权校验）
# ----------------------------------------------------------------
def _load_session(cur, sid: int, ctx: ToolContext) -> dict[str, Any]:
    sess = _one(cur, "SELECT * FROM `面试会话` WHERE `编号`=%s AND `租户编号`=%s",
                (sid, ctx.tenant_id))
    if not sess or int(sess["学生编号"]) != int(ctx.student_id or 0):
        raise HTTPException(404, "会话不存在或不属于本人")
    if sess["状态"] != "finished":
        raise HTTPException(409, "该场面试还没答完，暂不能生成分析")
    outline = json.loads(sess["提纲"] or "[]")
    answers = _rows(cur, "SELECT * FROM `面试问答` WHERE `会话编号`=%s ORDER BY `轮次`", (sid,))
    resume = _load_resume(cur, int(sess["简历编号"]), ctx.tenant_id) or {}
    snapshot = json.loads(sess["岗位要求快照"] or "null") or {}
    # 按轮次对齐（追问插入后 outline 与 answers 顺序仍一致，但用 map 更稳）
    amap = {int(a["轮次"]): a for a in answers}
    pairs = [(o, amap.get(int(o.get("round") or 0))) for o in outline]
    return {"sess": sess, "outline": outline, "answers": answers, "pairs": pairs,
            "resume": resume, "snapshot": snapshot,
            "job_skills": [str(s) for s in (snapshot.get("skill_tags") or [])]}


def _score_pairs(pairs: Sequence[tuple[Mapping, Mapping | None]],
                 evidence: Sequence[str], job_skills: Sequence[str]) -> list[dict | None]:
    """逐题确定性评分（与答题时同一函数，口径一致）。"""
    out: list[dict | None] = []
    for o, a in pairs:
        ans = (a or {}).get("学生回答")
        out.append(score_answer(ans, _rubric_of_q(o, job_skills), evidence))
    return out


def _dims_of(scores: Sequence[Mapping | None]) -> dict[str, float]:
    """整场四维百分制：已答题逐题折算后取均值；没答的维度不出现。"""
    acc: dict[str, list[float]] = defaultdict(list)
    for it in scores:
        if not it:
            continue
        dp = dimension_percent(it)
        for k in DIMS:
            if dp.get(k) is not None:
                acc[k].append(float(dp[k]))
    return {k: round(sum(v) / len(v), 2) for k, v in acc.items() if v}


def _probe_chain(outline: Sequence[Mapping], scores: Sequence[Mapping | None]) -> list[dict]:
    chain: list[dict] = []
    for o, s in zip(outline, scores):
        missed = list((s or {}).get("keyword_missed") or [])
        chain.append({
            "round": int(o.get("round") or 0),
            "label": QUESTION_TYPES.get(str(o.get("type")), {}).get("label", str(o.get("type"))),
            "question": str(o.get("question") or ""),
            "score": float(s["score"]) if s else None,
            "is_probe": bool(o.get("probe_of")),
            "probe_of": o.get("probe_of"),
            "gap": ("漏掉：" + "、".join(missed[:3])) if missed else "",
        })
    return chain


def _grade(total: float | None) -> str | None:
    if total is None:
        return None
    if total >= 85:
        return "A"
    if total >= 75:
        return "B+"
    if total >= 65:
        return "B"
    if total >= 55:
        return "C+"
    return "C"


# ----------------------------------------------------------------
# 1. 圆桌评审
# ----------------------------------------------------------------
@router.get("/panel/{sid}")
def panel_review(sid: int, llm: bool = False, ctx: ToolContext = Depends(require_student)) -> dict:
    conn = _conn()
    try:
        with conn.cursor() as cur:
            ctxd = _load_session(cur, sid, ctx)
        evidence = _evidence(ctxd["resume"], ctxd["snapshot"])
        scores = _score_pairs(ctxd["pairs"], evidence, ctxd["job_skills"])
        result = review(scores, ctxd["outline"], ctxd["job_skills"])
        if llm and result.get("consensus", {}).get("score") is not None:
            result["consensus"]["summary"] = _panel_summary(result, ctxd)
        return {"session_id": sid, "job_title": ctxd["sess"].get("岗位名称"),
                "panel": result, "job_skills": ctxd["job_skills"]}
    finally:
        conn.close()


def _panel_summary(result: Mapping, ctxd: Mapping) -> str:
    """模型只改写合议措辞；数字已由引擎算好，失败保留模板。"""
    facts = []
    for p in result.get("panelists") or []:
        facts.append(f"{p['title']}·{p['name']}：{p['score']} 分（{p['verdict']}），最在意{p['focus']}")
    c = result.get("consensus") or {}
    user = (
        f"岗位：{ctxd['sess'].get('岗位名称') or '通用岗位'}\n"
        + "\n".join(facts)
        + f"\n三人分差 {c.get('spread')} 分（{c.get('level')}），合议 {c.get('score')} 分。\n"
        + f"分歧点：{(result.get('divergence') or {}).get('note') or '无'}\n"
        "请写一段 90~140 字的合议总结：说明三人为什么看法不同、学生最该改的一件事。"
        "不得修改任何分数，不得编造学生没说过的内容。"
    )
    try:
        text = llm_client.generate_reply("teacher", system_prompt="你是校招面试评审组长，说话直接、不客套。",
                                         user_prompt=user, tag="panel.consensus")
        if text and text.strip():
            return text.strip()
    except Exception:
        pass
    return str(c.get("summary") or "")


# ----------------------------------------------------------------
# 2. 示范回答骨架
# ----------------------------------------------------------------
@router.get("/shadow/{sid}")
def shadow_items(sid: int, ctx: ToolContext = Depends(require_student)) -> dict:
    conn = _conn()
    try:
        with conn.cursor() as cur:
            ctxd = _load_session(cur, sid, ctx)
        evidence = _evidence(ctxd["resume"], ctxd["snapshot"])
        scores = _score_pairs(ctxd["pairs"], evidence, ctxd["job_skills"])
        terms = [str(t) for t in (ctxd["resume"].get("courses") or [])][:8]
        items = []
        for (o, a), s in zip(ctxd["pairs"], scores):
            items.append({
                "round": int(o.get("round") or 0),
                "label": QUESTION_TYPES.get(str(o.get("type")), {}).get("label", str(o.get("type"))),
                "question": str(o.get("question") or ""),
                "answer": ((a or {}).get("学生回答") or ""),
                "missed": list((s or {}).get("keyword_missed") or []),
                "shadow": shadow_engine.shadow(str(o.get("type") or "project"),
                                               _rubric_of_q(o, ctxd["job_skills"]), terms),
            })
        return {"session_id": sid, "items": items}
    finally:
        conn.close()


# ----------------------------------------------------------------
# 3. 表达力度量
# ----------------------------------------------------------------
@router.post("/expression")
def expression(inp: ExpressionIn, ctx: ToolContext = Depends(require_student)) -> dict:
    return expr_engine.analyze(inp.text or "", inp.duration_sec, inp.segments)


# ----------------------------------------------------------------
# 4. 能力护照
# ----------------------------------------------------------------
@router.get("/passport")
def passport(target: str | None = None, ctx: ToolContext = Depends(require_student)) -> dict:
    conn = _conn()
    try:
        with conn.cursor() as cur:
            sessions = _rows(
                cur,
                "SELECT `编号`,`岗位名称`,`总分`,`创建时间`,`完成时间`,`提纲`,`简历编号`,`岗位要求快照`"
                " FROM `面试会话` WHERE `租户编号`=%s AND `学生编号`=%s AND `状态`='finished'"
                " ORDER BY `创建时间`", (ctx.tenant_id, ctx.student_id))
            if not sessions:
                return passport_engine.build_passport([], _target_of(target))
            ids = [int(s["编号"]) for s in sessions]
            qa = _rows(cur, "SELECT `会话编号`,`轮次`,`问题类型`,`学生回答` FROM `面试问答`"
                            " WHERE `会话编号` IN (" + ",".join(["%s"] * len(ids)) + ")"
                            " ORDER BY `会话编号`,`轮次`", tuple(ids))
        by_sid: dict[int, list[dict]] = defaultdict(list)
        for r in qa:
            by_sid[int(r["会话编号"])].append(r)
        rows: list[dict] = []
        resume_cache: dict[int, dict] = {}
        for s in sessions:
            sid = int(s["编号"])
            outline = json.loads(s["提纲"] or "[]")
            snapshot = json.loads(s["岗位要求快照"] or "null") or {}
            skills = [str(x) for x in (snapshot.get("skill_tags") or [])]
            amap = {int(a["轮次"]): a for a in by_sid.get(sid, [])}
            pairs = [(o, amap.get(int(o.get("round") or 0))) for o in outline]
            # 证据必须逐场取真实值：传空会让 evidence 维度恒为 0，雷达图与报告页对不上
            rid = int(s.get("简历编号") or 0)
            if rid not in resume_cache:
                with conn.cursor() as cur2:
                    resume_cache[rid] = _load_resume(cur2, rid, ctx.tenant_id) or {}
            scores = _score_pairs(pairs, _evidence(resume_cache[rid], snapshot), skills)
            dims = _dims_of(scores)
            total = s.get("总分")
            if total is None:
                agg = aggregate(scores, outline)
                total = agg["total"] if agg else None
            rows.append({
                "session_id": sid,
                "date": str(s.get("完成时间") or s.get("创建时间") or "")[:10],
                "total": float(total) if total is not None else None,
                "job_title": s.get("岗位名称"),
                "dims": dims,
                "probes": sum(1 for o in outline if o.get("probe_of")),
                "spread": float(review(scores, outline, skills).get("consensus", {}).get("spread") or 0),
            })
        return passport_engine.build_passport(rows, _target_of(target))
    finally:
        conn.close()


def _target_of(raw: str | None) -> dict[str, float] | None:
    """?target=content:80,structure:75 形式；非法项忽略。"""
    if not raw:
        return None
    out: dict[str, float] = {}
    for part in raw.split(","):
        if ":" not in part:
            continue
        k, v = part.split(":", 1)
        k = k.strip()
        if k in DIMS:
            try:
                out[k] = max(0.0, min(100.0, float(v)))
            except ValueError:
                continue
    return out or None


# ----------------------------------------------------------------
# 5. 失分溯源到课程
# ----------------------------------------------------------------
@router.get("/attribution/{sid}")
def attribution(sid: int, ctx: ToolContext = Depends(require_student)) -> dict:
    conn = _conn()
    try:
        with conn.cursor() as cur:
            ctxd = _load_session(cur, sid, ctx)
            student = _one(cur, "SELECT `专业`,`年级` FROM `学生` WHERE `编号`=%s"
                                " AND `租户编号`=%s", (ctx.student_id, ctx.tenant_id)) or {}
            major, grade = student.get("专业"), student.get("年级")
            courses = _rows(
                cur,
                "SELECT c.`编号` AS course_id, c.`课程名称` AS name, c.`学分` AS credit,"
                "       MAX(g.`分数`) AS score"
                " FROM `成绩` g JOIN `课程` c ON c.`编号`=g.`课程编号`"
                " WHERE g.`学生编号`=%s GROUP BY c.`编号`"
                " ORDER BY c.`学分` DESC", (ctx.student_id,))
            # 同专业同年级该课的成绩分布 → 每门课的分位
            dist: dict[int, list[float]] = defaultdict(list)
            if major and grade:
                for r in _rows(
                        cur,
                        "SELECT g.`课程编号` AS cid, g.`分数` AS score"
                        " FROM `成绩` g JOIN `学生` st ON st.`编号`=g.`学生编号`"
                        " WHERE st.`专业`=%s AND st.`年级`=%s", (major, grade)):
                    dist[int(r["cid"])].append(float(r["score"]))
        evidence = _evidence(ctxd["resume"], ctxd["snapshot"])
        scores = _score_pairs(ctxd["pairs"], evidence, ctxd["job_skills"])
        # 漏考点按轮次归集（同一考点在多轮漏掉 → 更该被点名）
        missed_by_round: dict[int, list[str]] = {}
        for (o, _a), s in zip(ctxd["pairs"], scores):
            if s and s.get("keyword_missed"):
                missed_by_round[int(o.get("round") or 0)] = list(s["keyword_missed"])
        for c in courses:
            vals = dist.get(int(c["course_id"])) or []
            c["score"] = float(c["score"] or 0)
            c["percentile"] = peer_engine.percentile_of(c["score"], vals) if vals else None
            # 知识图谱的「课程→技能」映射：考点命中技能即可命中课程，比 2-gram 准得多
            c["skills"] = list(skills_for_course(str(c["name"])))
        return {"session_id": sid, "job_title": ctxd["sess"].get("岗位名称"),
                **attr_engine.attribute(missed_by_round, courses)}
    finally:
        conn.close()


# ----------------------------------------------------------------
# 6. 同辈分位
# ----------------------------------------------------------------
# 维度 → 课程名关键词（用于样本不足时的诚实代理基准，可解释、可复核）
_PROXY_HINTS = {
    "content": ("基础", "概论", "导论", "原理", "数学", "统计"),
    "structure": ("设计", "系统", "架构", "工程", "管理", "规划"),
    "depth": ("算法", "分析", "模型", "进阶", "高级", "优化"),
    "evidence": ("实验", "实践", "实训", "课程设计", "项目", "实习"),
}


@router.get("/peer/{sid}")
def peer_bench(sid: int, ctx: ToolContext = Depends(require_student)) -> dict:
    conn = _conn()
    try:
        with conn.cursor() as cur:
            ctxd = _load_session(cur, sid, ctx)
            student = _one(cur, "SELECT `专业`,`年级` FROM `学生` WHERE `编号`=%s"
                                " AND `租户编号`=%s", (ctx.student_id, ctx.tenant_id)) or {}
            major, grade = student.get("专业"), student.get("年级")
            cohort = 0
            samples: list[float] = []
            proxy: dict[str, list[float]] = {k: [] for k in DIMS}
            if major and grade:
                row = _one(cur, "SELECT COUNT(*) AS n FROM `学生` WHERE `专业`=%s AND `年级`=%s",
                           (major, grade))
                cohort = int((row or {}).get("n") or 0)
                # 实测样本：同专业同年级每人最新一场（避免同一人反复刷分把分布拉偏）
                samples = [float(r["total"]) for r in _rows(
                    cur,
                    "SELECT s.`总分` AS total FROM `面试会话` s"
                    " JOIN `学生` st ON st.`编号`=s.`学生编号`"
                    " WHERE st.`专业`=%s AND st.`年级`=%s AND s.`状态`='finished'"
                    "   AND s.`总分` IS NOT NULL"
                    "   AND s.`编号`=(SELECT MAX(s2.`编号`) FROM `面试会话` s2"
                    "               WHERE s2.`学生编号`=s.`学生编号` AND s2.`状态`='finished')",
                    (major, grade))]
                # 代理样本：每个学生各维度相关课程均分 → 个体层面的分布
                per_student: dict[int, dict[str, list[float]]] = defaultdict(lambda: {k: [] for k in DIMS})
                for r in _rows(
                        cur,
                        "SELECT g.`学生编号` AS sid, c.`课程名称` AS name, g.`分数` AS score"
                        " FROM `成绩` g JOIN `课程` c ON c.`编号`=g.`课程编号`"
                        " JOIN `学生` st ON st.`编号`=g.`学生编号`"
                        " WHERE st.`专业`=%s AND st.`年级`=%s", (major, grade)):
                    name = str(r["name"] or "")
                    for dim, hints in _PROXY_HINTS.items():
                        if any(h in name for h in hints):
                            per_student[int(r["sid"])][dim].append(float(r["score"]))
                for _sid, dims in per_student.items():
                    for dim, vals in dims.items():
                        if vals:
                            proxy[dim].append(round(sum(vals) / len(vals), 2))
        evidence = _evidence(ctxd["resume"], ctxd["snapshot"])
        scores = _score_pairs(ctxd["pairs"], evidence, ctxd["job_skills"])
        dims = _dims_of(scores)
        agg = aggregate(scores, ctxd["outline"])
        result = peer_engine.benchmark(agg["total"] if agg else None, dims, samples, cohort,
                                       {k: v for k, v in proxy.items() if v})
        return {"session_id": sid, **result}
    finally:
        conn.close()


# ----------------------------------------------------------------
# 7. 复盘卡
# ----------------------------------------------------------------
@router.get("/report-card/{sid}")
def report_card(sid: int, ctx: ToolContext = Depends(require_student)) -> dict:
    conn = _conn()
    try:
        with conn.cursor() as cur:
            ctxd = _load_session(cur, sid, ctx)
        evidence = _evidence(ctxd["resume"], ctxd["snapshot"])
        scores = _score_pairs(ctxd["pairs"], evidence, ctxd["job_skills"])
        panel = review(scores, ctxd["outline"], ctxd["job_skills"])
        agg = aggregate(scores, ctxd["outline"])
        problems = core_problems(scores, ctxd["outline"])
        gaps = gap_list(ctxd["resume"], {"title": ctxd["sess"].get("岗位名称"),
                                        "skill_tags": ctxd["job_skills"]}, scores, ctxd["outline"])
        plan = improvement_plan(gaps, problems)
        dims = _dims_of(scores)
        return {
            "session_id": sid,
            "job_title": ctxd["sess"].get("岗位名称"),
            "date": str(ctxd["sess"].get("完成时间") or ctxd["sess"].get("创建时间") or "")[:10],
            "total": agg["total"] if agg else None,
            "grade": _grade(agg["total"] if agg else None),
            "panel": panel,
            "passport_dot": dims,
            "probe_chain": _probe_chain(ctxd["outline"], scores),
            "top_problems": [f"[{p['dimension']}] {p['problem']}" for p in problems][:3],
            "next_actions": [f"{s['when']}｜{s['focus']}：{s['action']}" for s in plan][:2]
                            or [f"{g['dimension']}：{g['action']}" for g in gaps][:2],
            "expression": None,
        }
    finally:
        conn.close()


# ----------------------------------------------------------------
# 8. 群面（无领导小组讨论）
# ----------------------------------------------------------------
def _prune_groups() -> None:
    now = time.time()
    for gid in [k for k, v in _GROUP_SESSIONS.items() if now - v["ts"] > _GROUP_TTL]:
        _GROUP_SESSIONS.pop(gid, None)
    while len(_GROUP_SESSIONS) > _GROUP_MAX:
        oldest = min(_GROUP_SESSIONS.items(), key=lambda kv: kv[1]["ts"])[0]
        _GROUP_SESSIONS.pop(oldest, None)


def _group_speak(system: str, user: str) -> str:
    """群面发言调用模型；任何异常向上抛，由 engine.group 的降级兜住。"""
    text = llm_client.generate_reply("student", system_prompt=system, user_prompt=user,
                                     tag="group.turn")
    if not text:
        raise RuntimeError("模型未返回内容")
    return str(text)


@router.post("/group/start")
def group_start(inp: GroupStartIn, ctx: ToolContext = Depends(require_student)) -> dict:
    title, industry, skills = inp.job_title, inp.industry, list(inp.skills or [])
    if inp.job_id:
        conn = _conn()
        try:
            with conn.cursor() as cur:
                job = _one(cur, "SELECT `岗位名称`,`行业`,`技能标签` FROM `岗位` WHERE `编号`=%s",
                           (inp.job_id,))
            if job:
                title = title or job.get("岗位名称")
                industry = industry or job.get("行业")
                if not skills:
                    raw = job.get("技能标签")
                    skills = json.loads(raw) if isinstance(raw, str) else list(raw or [])
        finally:
            conn.close()
    topic = group_engine.make_topic(title or "数据分析岗", industry, skills)
    state = {"version": group_engine.GROUP_VERSION, "topic": topic, "turns": [],
             "student_turns": [], "elapsed_turns": 0}
    op = group_engine.opening(topic)
    state["turns"].append(op["first_turn"])
    state["elapsed_turns"] = 1
    gid = uuid.uuid4().hex[:12]
    _prune_groups()
    _GROUP_SESSIONS[gid] = {"ts": time.time(), "student_id": ctx.student_id}
    return {"group_id": gid, "topic": topic, "opening": op, "state": state}


@router.post("/group/turn")
def group_turn(inp: GroupTurnIn, ctx: ToolContext = Depends(require_student)) -> dict:
    state = dict(inp.state or {})
    text = (inp.text or "").strip()
    ai_turns: list[dict] = []
    try:
        if text:
            r = group_engine.student_turn(state, text)
            state = r["state"]
        # 下一位 AI：按已发言的 AI 数轮转 ice → data → spark
        ai_count = sum(1 for t in state.get("turns") or [] if t.get("speaker") != "student")
        cand = group_engine.CANDIDATES[ai_count % len(group_engine.CANDIDATES)]
        r2 = group_engine.ai_turn(state, cand["id"], _group_speak)
        state = r2["state"]
        ai_turns.append(r2["turn"])
    except ValueError as exc:
        raise HTTPException(422, str(exc))
    return {"state": state, "ai_turns": ai_turns, "source": r2.get("source")}


@router.post("/group/finish")
def group_finish(inp: GroupTurnIn, ctx: ToolContext = Depends(require_student)) -> dict:
    try:
        return group_engine.evaluate(inp.state or {})
    except ValueError as exc:
        raise HTTPException(422, str(exc))
